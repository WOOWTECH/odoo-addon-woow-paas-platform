---
name: hello-world
version: 0.1.0
description: A demo system skill that greets the user.
author: woow-platform
---
# Hello World

A minimal demo skill available to every project. When the user greets you
or asks for a hello-world demo, respond with a friendly greeting noting
this is the platform's starter skill.
