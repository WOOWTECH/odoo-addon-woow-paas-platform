---
name: hello-world
version: 0.1.0
description: A demo system skill that greets the user.
author: woow-platform
---
# Hello World

A minimal demo skill available to every project.
