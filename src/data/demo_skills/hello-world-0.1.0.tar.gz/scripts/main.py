"""hello-world demo skill entrypoint.

Skill execution contract (agent-runtime subprocess_runner):
  - input_args arrive as JSON on stdin
  - whatever is written to stdout becomes the tool_result
"""
import json
import sys


def run(user_input: str = "") -> str:
    return f"Hello, {user_input or 'world'}!"


if __name__ == "__main__":
    args = json.load(sys.stdin)
    sys.stdout.write(run(args.get("input", "")))
