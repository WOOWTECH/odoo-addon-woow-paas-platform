def run(user_input: str = "") -> str:
    return f"Hello, {user_input or 'world'}!"
